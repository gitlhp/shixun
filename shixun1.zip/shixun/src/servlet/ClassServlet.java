package servlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ClassBean;
import bean.StudentBean;
import bpo.ClassBpo;
import bpo.StudentBpo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class ClassServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");//是设置从request中取得的值或从数据库中取出的值
		response.setContentType("text/html;charset=utf-8");   //是设置页面中为中文编码 
		response.setHeader("Cache-Control","no-cache"); 
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
		//1
		if(mode.equals("gets")){//获得专业列表
			String specid=request.getParameter("speciality");//valueField:'specid',textField:'specname'
			try{
				List<ClassBean> classs=new ArrayList<ClassBean>();
				ClassBpo classbpo=new ClassBpo();
				classs=classbpo.getAllinfo(specid);
				Gson gson = new Gson();
				result=gson.toJson(classs);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else if(mode.equals("get")){//根据班级名称获得学生基本信息
			String classname=request.getParameter("classname");
			try{
				ClassBpo classbpo=new ClassBpo();
				ClassBean classone =classbpo.getByclassname(classname);
				Gson gson = new Gson();
				result=gson.toJson(classone);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("edt")){//增加班级
			String classjson=request.getParameter("classone");
			String flag=request.getParameter("flag");//1为增加，2修改
			//	System.out.println(classjson);
			try{
				Type type = new TypeToken<ClassBean>(){}.getType();  
				Gson gson = new Gson();
				ClassBean classone=gson.fromJson(classjson,type);
				ClassBpo classbpo=new ClassBpo();
				if(flag.equals("1")){
					classbpo.addinfo(classone);
				}else{
					classbpo.modifyinfo(classone);
				}
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("del")){//删除学生信息
			String classname=request.getParameter("classname");
			try{
				ClassBpo classbpo=new ClassBpo();
				classbpo.deleteinfo(classname);
			}catch(Exception e){
				errmsg=e.getMessage();//e.toString()获取的信息包括异常类型和异常详细消息，而e.getMessage()只是获取了异常的详细消息字符串
			}
		}
		else{
			errmsg=mode+"未定义";
		}	
		//2
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");//这里就是把集合数据提交到前端
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");//传递JSON数据类型给Ajax回调函数方法
		}
	}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
