package servlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.StudentBean;
import bean.SyscodeBean;
import bpo.StudentBpo;
import bpo.SyscodeBpo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class SyscodeServlet extends HttpServlet{
	private static final long serialVersionUID = 1L; 
	protected void doGet(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");  
		response.setHeader("Cache-Control","no-cache");
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
		if(mode.equals("getcodeByno")){  //按照codeno获得教师相应下拉列表框的值
			String codeno=request.getParameter("codeno");
			List<SyscodeBean> codes=new ArrayList<SyscodeBean>();
			try{
				SyscodeBpo syscode=new SyscodeBpo();
				codes = syscode.getcodeByno(codeno);
				Gson gson = new Gson();		
				result=gson.toJson(codes);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else if(mode.equals("getlist")){//获得代码表中的所有代码值
			List<SyscodeBean> codes=new ArrayList<SyscodeBean>();
			try{
				SyscodeBpo syscode=new SyscodeBpo();
				codes = syscode.getAllinfo();
				Gson gson = new Gson();		
				result=gson.toJson(codes);
				System.out.println(result);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("gets")){//获得代码表中的所有代码值
			String codename=request.getParameter("codename");
			List<SyscodeBean> codes=new ArrayList<SyscodeBean>();
			try{
				SyscodeBpo syscode=new SyscodeBpo();
				codes = syscode.getAllinfo(codename);
				Gson gson = new Gson();		
				result=gson.toJson(codes);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else if(mode.equals("get")){//根据代码id获得代码基本信息  根据任务书好像我没用到？
			String codeid=request.getParameter("codeid");
			try{
				SyscodeBpo syscodeBpo=new SyscodeBpo();
				SyscodeBean sBean=syscodeBpo.getcodeByid(codeid);
				Gson gson = new Gson();
				result=gson.toJson(sBean);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("edt")){//增加代码
			String codejson=request.getParameter("code");
			String flag=request.getParameter("flag");//1为增加，2修改
			//System.out.println(codejson);
			try{
				Type type = new TypeToken<SyscodeBean>(){}.getType();  
				Gson gson = new Gson();
				SyscodeBean codeBean=gson.fromJson(codejson,type);
				SyscodeBpo codebpo=new SyscodeBpo();
				if(flag.equals("1")){
					codebpo.addOrmod(codeBean);
				}else{
					codebpo.modifyinfo(codeBean);
				}
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("del")){//删除学生信息
			String codeid=request.getParameter("codeid");
			try{
				SyscodeBpo codebpo=new SyscodeBpo();
				codebpo.deleteinfo(codeid);
			}catch(Exception e){
				errmsg=e.getMessage();//e.toString()获取的信息包括异常类型和异常详细消息，而e.getMessage()只是获取了异常的详细消息字符串
			}
		}
		else{
			errmsg=mode+"未定义";
		}
		
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");
		}
	}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
