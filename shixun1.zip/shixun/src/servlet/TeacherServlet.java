package servlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.StudentBean;
import bean.TeacherBean;
import bpo.StudentBpo;
import bpo.TeacherBpo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class TeacherServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");   
		response.setHeader("Cache-Control","no-cache"); 
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
	//1
	if(mode.equals("gets")){//获得教师列表
		String tdept=request.getParameter("tdept");
		String tid=request.getParameter("tid");
		String tname=request.getParameter("tname");
		try{
			List<TeacherBean> teachers=new ArrayList<TeacherBean>();
			TeacherBpo teacherbpo=new TeacherBpo();
			teachers=teacherbpo.getAllinfo(tdept,tid,tname);
			Gson gson = new Gson();
			result=gson.toJson(teachers);

		}catch(Exception e){
			errmsg=e.getMessage();
		}
	}else if(mode.equals("get")){//根据学号获得学生基本信息
		String tid=request.getParameter("tid");
		try{
			TeacherBpo teacherbpo=new TeacherBpo();
			TeacherBean teacher=teacherbpo.getBytid(tid);
			Gson gson = new Gson();
			result=gson.toJson(teacher);
		}catch(Exception e){
			errmsg=e.getMessage();
		}
	}
	else if(mode.equals("edt")){//
		String teacherjson=request.getParameter("teacher");
		String flag=request.getParameter("flag");//1为增加，2修改
		
		System.out.println(teacherjson);
		try{
			Type type = new TypeToken<TeacherBean>(){}.getType();  
			Gson gson = new Gson();
			TeacherBean teacher=gson.fromJson(teacherjson,type);
			TeacherBpo teacherbpo=new TeacherBpo();
			if(flag.equals("1")){
				teacherbpo.addinfo(teacher);
			}else{
				teacherbpo.modifyinfo(teacher);
			}
		}catch(Exception e){
			errmsg=e.getMessage();
		}
	}
	else if(mode.equals("del")){//删除教师信息
		String tid=request.getParameter("tid");
		System.out.println(tid);
		try{
			TeacherBpo teacherbpo=new TeacherBpo();
			teacherbpo.deleteinfo(tid);
		}catch(Exception e){
			errmsg=e.getMessage();//e.toString()获取的信息包括异常类型和异常详细消息，而e.getMessage()只是获取了异常的详细消息字符串
		}
	}
	else{
		errmsg=mode+"未定义";
	}
	//2
	if(result.equals("")){
		response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");//这里就是把集合数据提交到前端
	}else{
		response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");//传递JSON数据类型给Ajax回调函数方法
	}
}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
