package servlet;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bpo.ExcelBpo;

public class ExcelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException,IOException {
		
		response.setContentType("text/html;charset=utf-8");   
		response.setHeader("Cache-Control","no-cache"); 
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
		//System.out.print(mode);
		try{
			ExcelBpo excelbpo=new ExcelBpo();
			if(mode.equals("importstudents")){//导入学生基本信息 (1)
				InputStream stream=null ;
				try{
					boolean isMultipart = ServletFileUpload.isMultipartContent(request);//判断请求中是否有enctype="multipart/form-data“这种标示。
					if(isMultipart==true){//(2)1
						//首先得到文件的输入流，并不上传文件
						ServletFileUpload upload = new ServletFileUpload();//文件上传组件处理文件上传的核心高级
						//isMultipartContent方法方法用于判断请求消息中的内容是否是“multipart/form-data”类型，是则返回true，
						//否则返回false。isMultipartContent方法是一个静态方法，不用创建ServletFileUpload类的实例对象即可被调用。
						upload.setHeaderEncoding("UTF-8");//解决文件名中文乱码
						FileItemIterator iter = upload.getItemIterator(request);//getItemIterator方法返回的是一个迭代器，该迭代器中保存的不是FileItem对象，而是FileItemStream 对象，如果你希望进一步提高新能，你可以采用getItemIterator方法，
					/*
					 * getItemIterator=-parseRequest 方法是ServletFileUpload类的重要方法，
					 * 它是对HTTP请求消息体内容进行解析的入口方法。
					 * 它解析出FORM表单中的每个字段的数据，并将它们分别包装成独立的FileItem对象，
					 * 然后将这些FileItem对象加入进一个List类型的集合对象中返回
					 * ServletFileUpload upload = new ServletFileUpload(factory);
try { 
List<FileItem> items = upload.parseRequest(request); //解析request请求
Iterator iter = items.iterator();
					 */
					//直接获得每一个文件项的数据输入流，
						if (iter.hasNext()) {
							FileItemStream item = iter.next();//该流用于从文件读取数据 在Java中，能够读取一个字节序列的对象就称作一个输入流
						    stream = item.openStream();//读取
						    excelbpo.importstudents(stream);
						    //System.out.print("222222");
						}
					}else{//(2)
						throw new Exception("导入文件表单属性应为enctype='multipart/form-data'");
					}
				}catch(Exception e){
					throw e;
				}finally{
					if(stream!=null) stream.close();
				}
			}//(1)
			else if(mode.equals("importteachers")){//导入教师基本信息)2
				// System.out.print("222222");
				InputStream stream=null ;
				try{
					boolean isMultipart = ServletFileUpload.isMultipartContent(request);
					if(isMultipart==true){//(2)
						//首先得到文件的输入流，并不上传文件
						ServletFileUpload upload = new ServletFileUpload();
						upload.setHeaderEncoding("UTF-8");
						FileItemIterator iter = upload.getItemIterator(request);
					//直接获得每一个文件项的数据输入流，
						//System.out.print("33333");
						if (iter.hasNext()) {
							//System.out.print("4444");
							FileItemStream item = iter.next();
							//System.out.print("5555");
						    stream = item.openStream();//读取
						   // System.out.print("6666");
						    excelbpo.importteachers(stream);
						   // System.out.print("7777");
						}
					}else{//(2)3
						throw new Exception("导入文件表单属性应为enctype='multipart/form-data'");
					}
				}catch(Exception e){
					throw e;
				}finally{
					if(stream!=null) stream.close();
				}
				//errmsg=mode+"待定义";
			}
			else{
				throw new Exception("调用方法'"+mode+"'不存在！");
			}
			
		}catch(Exception e){
			errmsg=e.getMessage();
		}//第一个try
		
		//响应内容
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");
		}
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}
}
