package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import bpo.UserBpo;

import com.google.gson.Gson;
public class UserServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request,
			   HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8");   
		response.setHeader("Cache-Control","no-cache"); 
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
		
		if(mode.equals("get")){
			String userid=request.getParameter("userid");
			try{
				UserBpo userbpo=new UserBpo();
				UserBean user=userbpo.getinfo_userid(userid);
				Gson gson = new Gson();
				result=gson.toJson(user);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else if(mode.equals("getSysusers")){//
			String userid=request.getParameter("userid");
			List<UserBean> users=new ArrayList<UserBean>();
			try {
				UserBpo userbpo=new UserBpo();
				users=userbpo.getSysusers(userid);
				Gson gson = new Gson();
				result=gson.toJson(users);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else{
			errmsg=mode+"方法不存在！";
		}
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");
		}
	}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
