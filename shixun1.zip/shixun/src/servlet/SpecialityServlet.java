package servlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SpecialityBean;
import bean.StudentBean;
import bpo.SpecialityBpo;
import bpo.StudentBpo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class SpecialityServlet extends HttpServlet{
	private static final long serialVersionUID = 1L; 
	protected void doGet(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=utf-8");   
		response.setHeader("Cache-Control","no-cache"); 
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
		if(mode.equals("gets")){
			List<SpecialityBean> specs=new ArrayList<SpecialityBean>();
			try{
				SpecialityBpo specbpo=new SpecialityBpo();
				specs=specbpo.getAllinfo();
				Gson gson = new Gson();		
				result=gson.toJson(specs);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}else if(mode.equals("edt")){//修改教师部分信息
			String specjson=request.getParameter("spec");
			try{
				Type type = new TypeToken<SpecialityBean>(){}.getType();  
				Gson gson = new Gson();
				SpecialityBean spec=gson.fromJson(specjson,type);
				/*String specid=spec.getSpecid();
				String specmagtid=spec.getSpecmagtid();
				if (specmagtid==null) {
					specmagtid="";
				}				
				specbpo.modifySpecMag(specid, specmagtid);
				*/
				SpecialityBpo specbpo=new SpecialityBpo();
				specbpo.modifySpecMag(spec);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else{
			errmsg=mode+"未定义";
		}
	//回调	
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");
		}
	}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
