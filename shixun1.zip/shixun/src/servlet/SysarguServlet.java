package servlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SysarguBean;
import bean.SyscodeBean;
import bpo.SysarguBpo;
import bpo.SyscodeBpo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class SysarguServlet extends HttpServlet{
	private static final long serialVersionUID = 1L; 
	protected void doGet(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");  
		response.setHeader("Cache-Control","no-cache");
		String result="";
		String errmsg="";
		String mode=request.getParameter("mode");
	    if(mode.equals("getlist")){//获得代码表中的所有代码值
			List<SysarguBean> argus=new ArrayList<SysarguBean>();
			try{
				SysarguBpo argubpo=new SysarguBpo();
				argus= argubpo.getAllsysargu();
				Gson gson = new Gson();		
				result=gson.toJson(argus);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("gets")){//获得代码表中的所有代码值
			String arguname=request.getParameter("arguname");
			List<SysarguBean> argus=new ArrayList<SysarguBean>();
			try{
				SysarguBpo argubpo=new SysarguBpo();
				argus= argubpo.getSysargu(arguname);
				Gson gson = new Gson();		
				result=gson.toJson(argus);
				//System.out.println(result);//此处没毛病老铁
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else if(mode.equals("edt")){//增加代码
			String argujson=request.getParameter("argu");
			try{
				Type type = new TypeToken<SysarguBean>(){}.getType();  
				Gson gson = new Gson();
				SysarguBean arguBean=gson.fromJson(argujson,type);
				String  arguname=arguBean.getArguname();
				String  arguvalue=arguBean.getArguvalue();
				SysarguBpo argubpo=new SysarguBpo();
				argubpo.modifyArguByName(arguname, arguvalue);
			}catch(Exception e){
				errmsg=e.getMessage();
			}
		}
		else{
			errmsg=mode+"未定义";
		}
		if(result.equals("")){
			response.getWriter().write("{\"errmsg\":\""+errmsg+"\"}");
		}else{
			response.getWriter().write("{\"result\":"+result+",\"errmsg\":\""+errmsg+"\"}");
		}
	}
	protected void doPost(HttpServletRequest request,
	   HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}
}
