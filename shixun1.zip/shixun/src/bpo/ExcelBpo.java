package bpo;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import bean.StudentBean;
import bean.TeacherBean;

public class ExcelBpo {
	//导入学生基本信息
	public void importstudents(InputStream stream)throws Exception{
		Workbook workbook =null;//workbook是一个工作簿   和创建一个输入流。。。类死把 
		try{
	        //读取文件输入流中的内容
		    workbook = Workbook.getWorkbook(stream);
		    //可以直接从输入流中读取  也可以直接读取文件Workbook.getWorkbook(new File(sourceFile))
		    int count=workbook.getNumberOfSheets();//获取工作簿中工作表的个数   
		    //System.out.println("表单数："+String.valueOf(count));
		    List<StudentBean> students=new ArrayList<StudentBean>();
		    for(int m=0;m<count;m++){
		    	Sheet sheet = workbook.getSheet(m); //获取第一个工作表对象，getSheet()中的参数表示第几张工作表，索引从0开始
	            //int col=sheet.getColumns();
	            int row=sheet.getRows();//Sheet页的总行数
	            //System.out.println(String.valueOf(row));
	            String sheetname=sheet.getName();//返回Sheet标题  返回这张表的标题
	            //System.out.println(sheetname);
	            for(int i=1;i<row;i++){//学生表一共就三列  学号，姓名，班级 trim()：去掉收尾字符串“  abc   ”->“abc”
	        		String stuid=sheet.getCell(0,i).getContents().trim();//返回第一行,第一列的值  (0 (第一个代表列),i (第i行))
	        		String sname=sheet.getCell(1,i).getContents();
	        		String classname=sheet.getCell(2,i).getContents();//获取单元格的内容  一行一列是22222   则返回22222 
	        		if(stuid.equals("")) break;//学号都没有  呵呵。。
	        		//检查读入信息的有效性
	        		if(!(stuid.length()==10))throw new Exception("表单<"+sheetname+">中学号"+stuid+"出错,应为10位字符！");//越界
	        		StudentBean temp=new StudentBean();
	        		temp.setStuid(stuid);
	        		temp.setSname(sname);
	        		temp.setClassname(classname);
	        		students.add(temp);//添加到集合中
	            }
		    }
		    //将学生维护到数据库
		    StudentBpo studentbpo=new StudentBpo();
		    studentbpo.addinfoBatch(students);
		}catch(Exception e){
			throw e;
		}finally{
			if(workbook!=null) workbook.close();//关闭Workbook对象，释放占用的内存空间一般  创建对象用完就释放掉 浪费。。
		}
	}
	//导入教师数据
	public void importteachers(InputStream stream)throws Exception{
		//System.out.print("888");
		Workbook workbook =null;//workbook是一个工作簿   和创建一个输入流。。。类死把 
		try{
	        //读取文件输入流中的内容
			//System.out.print("9999");
		    workbook = Workbook.getWorkbook(stream);
		    //可以直接从输入流中读取  也可以直接读取文件Workbook.getWorkbook(new File(sourceFile))
		    int count=workbook.getNumberOfSheets();//获取工作簿中工作表的个数   
		    //System.out.println("表单数："+String.valueOf(count));
		    List<TeacherBean> teachers=new ArrayList<TeacherBean>();
		    for(int m=0;m<count;m++){
		    	Sheet sheet = workbook.getSheet(m); //获取第一个工作表对象，getSheet()中的参数表示第几张工作表，索引从0开始
	            //int col=sheet.getColumns();
	            int row=sheet.getRows();//Sheet页的总行数
	            //System.out.println(String.valueOf(row));
	            String sheetname=sheet.getName();//返回Sheet标题  返回这张表的标题
	           // System.out.println(sheetname);
	            for(int i=1;i<row;i++){//学生表一共就三列  学号，姓名，班级 trim()：去掉收尾字符串“  abc   ”->“abc”
	        		//System.out.println("345654");
	            	String tid=sheet.getCell(0,i).getContents().trim();//定位 然后返回第一行,第一列的值  (0 (第一个代表列),i (第i行))
	        		String tname=sheet.getCell(1,i).getContents();
	        		//System.out.println(tname);
	        		String tdept=sheet.getCell(2,i).getContents();//获取单元格的内容  一行一列是22222   则返回22222 
	        		String tpost=sheet.getCell(3,i).getContents();
	        		// System.out.println(tname);
	        		String tdegree=sheet.getCell(4,i).getContents();
	        		//System.out.print("kkkkkkj");//程序到这里就不走了
	        		if(tid.equals("")) break;//职工号号都没有  呵呵。。
	        		//检查读入信息的有效性
	        		if(!(tid.length()==6))throw new Exception("表单<"+sheetname+">中职工号号"+tid+"出错,应为6位字符！");//越界
	        		//System.out.print("lllll");
	        		TeacherBean temp=new TeacherBean();
	        		temp.setTid(tid);
	        		temp.setTname(tname);
	        		temp.setTdept(tdept);
	        		temp.setTpost(tpost);
	        		temp.setTdegree(tdegree);	        	
	        		teachers.add(temp);//添加到集合中
	        		//int n=teachers.size();
	        		//System.out.println(String.valueOf(n));
	        		//System.out.println(sheetname+":"+stuid+","+sname+","+classname);
	        		//System.out.print("nnnnn");
	            }
		    }
		    //将教师维护到数据库
		    TeacherBpo teacherbpo=new TeacherBpo();
		    teacherbpo.addinfoBatch(teachers);
		}catch(Exception e){
			throw e;
		}finally{
			if(workbook!=null) workbook.close();//关闭Workbook对象，释放占用的内存空间一般  创建对象用完就释放掉 浪费。。
		}
	}
}
