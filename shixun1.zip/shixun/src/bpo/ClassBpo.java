package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.ClassBean;
import bean.StudentBean;

import com.dbconnection;

public class ClassBpo {
	/**增加一个班级*/
	public void addinfo(ClassBean clas)throws Exception 
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		String specid="";
		//有效性验证
		String vsql ="select * from tb_class where classname='"+clas.getClassname()+"'";
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next())
			{
				if(clas.getClassname().equals(rst.getString("classname")))
				{ 
					throw new Exception(clas.getClassname()+"已存在！");
				}
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, null);
		}
		//判断专业号是否有效
		try{
			vsql="select * from tb_speciality where specid='"+clas.getSpecid()+"'";
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(!rst.next()) 
			 throw new Exception(clas.getClassname()+"的专业不存在！");
		      }catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, null);
		}
		//con.setAutoCommit(false);//不自动 Commit (瓜子不是一个一个吃,全部剥开放桌子上,然后一口舔了)
		PreparedStatement pstmt1=null;
		try{
			vsql="insert into tb_class (classname,specid,enrolyear,gradyear) values(?,?,?,?)";
			pstmt=con.prepareStatement(vsql);
			pstmt.setString(1,clas.getClassname());
			pstmt.setString(2,clas.getSpecid());
			pstmt.setString(3,clas.getEnrolyear());
			pstmt.setString(4,clas.getGradyear());
			pstmt.executeUpdate();
			//con.commit();//提交事务
		}catch(Exception e){
			//con.rollback();
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
			//con.setAutoCommit(true);
		}
	}
	/**按专业得到班级信息*/
	public List<ClassBean> getAllinfo(String specid)throws Exception
	{  
		Connection con=dbconnection.getConnection();
		if(specid==null) specid="";
		String vsql="select * from tb_class where specid like '"+specid+"%' order by specid,classname";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		List<ClassBean> ret=new ArrayList<ClassBean>();
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			while(rst.next())
			{
				ClassBean temp=new ClassBean();
				temp.setClassid(rst.getString("classid"));
				temp.setClassname(rst.getString("classname"));
				String strspecid=rst.getString("specid");
				temp.setSpecid(rst.getString("specid"));
				SpecialityBpo specbpo=new SpecialityBpo();
				temp.setSpeciality(specbpo.getByspecid(strspecid));
				temp.setEnrolyear(rst.getString("enrolyear"));
				temp.setGradyear(rst.getString("gradyear"));
				ret.add(temp);
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return ret;
	}
	/**根据班级名获得班级信息*/
	public ClassBean getByclassname(String classname)throws Exception
	{
		    Connection con=dbconnection.getConnection();
			String vsql="select * from tb_class where classname = '"+classname+"'";
			PreparedStatement pstmt=con.prepareStatement(vsql);
			ResultSet rst=pstmt.executeQuery();
			ClassBean temp=new ClassBean();
	while(rst.next())
	{    
		temp.setClassid(rst.getString("classid"));
		temp.setClassname(rst.getString("classname"));
		temp.setSpecid(rst.getString("specid"));
		temp.setEnrolyear(rst.getString("enrolyear"));
		temp.setGradyear(rst.getString("gradyear"));
	}
	dbconnection.close(rst, pstmt, con);
	return temp;
}
	/**修改班级信息有点问题*/
	public void modifyinfo(ClassBean clas)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		//判断专业号是否有效
				try{
				String	vsql="select * from tb_speciality where specid='"+clas.getSpecid()+"'";
					pstmt=con.prepareStatement(vsql);
					rst=pstmt.executeQuery();
					if(!rst.next()) 
					 throw new Exception(clas.getClassname()+"的专业不存在！修改无效！");
				      }catch(Exception e){
					throw e;
				}finally{
					dbconnection.close(rst, pstmt, null);
				}
		    try{
			String vsql="update tb_class set classname=?,specid=?,enrolyear=?,gradyear=? where classid=?";
		    pstmt=con.prepareStatement(vsql);		
			pstmt.setString(1,clas.getClassname());
			pstmt.setString(2,clas.getSpecid());
			pstmt.setString(3,clas.getEnrolyear());
			pstmt.setString(4,clas.getGradyear());
			pstmt.setString(5,clas.getClassid());
			//pstmt.executeUpdate();
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(null, pstmt, con);
		}
	}
	/**删除班级信息*/
	public void deleteinfo(String classname)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			String vsql="delete from tb_class where classname='"+classname+"'";
			pstmt=con.prepareStatement(vsql);
			pstmt.executeUpdate();		
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(null, pstmt, con);
		}
	}
	
}
