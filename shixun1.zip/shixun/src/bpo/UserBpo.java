package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.UserBean;

import com.dbconnection;

public class UserBpo {
	public UserBpo()throws Exception
	{
	}
	public void addinfo(UserBean user)throws Exception 
	{
		//Connection con=DatabaseConn.getConnection();
		Connection con=dbconnection.getConnection();
		//有效性验证
		String vsql ="select * from tb_user where userid='"+user.getUserid()+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next())
		{
			if(user.getUserid().equals(rst.getString("userid")))
			{ 
				throw new Exception("用户已存在！");
			}
		}
		///////////////////////////////////////////////////////////
		vsql="insert into tb_user(usertype,userid,username,userpwd) values(?,?,?,?)";
		pstmt=con.prepareStatement(vsql);
		pstmt.setString(1,user.getUsertype());
		pstmt.setString(2,user.getUserid());
		pstmt.setString(3,user.getUsername());
		pstmt.setString(4,"e10adc3949ba59abbe56e057f20f883e");//新增用户默认密码为123456
		
		try{
			pstmt.execute();
		}
		catch(Exception e){
			throw e;
		}
		dbconnection.close(rst, pstmt, con);
		//DatabaseConn.close(con, pstmt, rst);
	}
	public List<UserBean> getAllinfo()throws Exception
	{  	Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		String vsql="select * from tb_user order by usertype,userid";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		List<UserBean> ret=new ArrayList<UserBean>();
		while(rst.next())
		{
			UserBean temp=new UserBean();
			temp.setUsertype(rst.getString("usertype"));
			temp.setUserid(rst.getString("userid"));
			temp.setUserpwd(rst.getString("userpwd"));
			temp.setUsername(rst.getString("username"));
			ret.add(temp);
		}
		//DatabaseConn.close(con, pstmt, rst);
		dbconnection.close(rst, pstmt, con);
		return ret;
	}
	public List<UserBean> getSysusers(String userid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		String vsql="select * from tb_user where userid like '"+userid+"%'"+
		            " and usertype not in('教师','学生')"+
		            " order by usertype,userid";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		List<UserBean> ret=new ArrayList<UserBean>();
		while(rst.next())
		{
			UserBean temp=new UserBean();
			temp.setUsertype(rst.getString("usertype"));
			temp.setUserid(rst.getString("userid"));
			//temp.setUserpwd(rst.getString("userpwd"));
			temp.setUsername(rst.getString("username"));
			ret.add(temp);
		}
		dbconnection.close(rst, pstmt, con);
		//DatabaseConn.close(con, pstmt, rst);
		return ret;
	}
	public UserBean getinfo_userid(String userid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		if(null == userid){
			userid="";
		}	
		String vsql="select * from tb_user where userid like '"+userid+"%'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		UserBean temp=new UserBean();
		while(rst.next())
		{
			temp.setUsertype(rst.getString("usertype"));
			temp.setUserid(rst.getString("userid"));
			temp.setUserpwd(rst.getString("userpwd"));
			temp.setUsername(rst.getString("username"));
		}
		dbconnection.close(rst, pstmt, con);
		//DatabaseConn.close(con, pstmt, rst);
		return temp;
	}
	public void modifyinfo(UserBean user)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		//有效性验证
		PreparedStatement pstmt=null;
		String vsql;
		///////////////////////////////////////////////////////////
		vsql="update tb_user set usertype=?,username=? where userid=? ";
	    pstmt=con.prepareStatement(vsql);
	    pstmt.setString(1,user.getUsertype());
		pstmt.setString(2,user.getUsername());
		pstmt.setString(3,user.getUserid());
		pstmt.execute();
		//DatabaseConn.close(con, pstmt, null);
		dbconnection.close(null, pstmt, con);
	}
	public void modifyPwd(String userid,String oldpwd,String newpwd)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		UserBean user=new UserBean();
		//密码需MD5加密
		
		user.setUserid(userid);
		user.setUserpwd(oldpwd);
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		String vsql;
		vsql ="select * from tb_user where userid='"+userid+"'";
		pstmt=con.prepareStatement(vsql);
		try{
			rst=pstmt.executeQuery();
			if(!rst.next()){throw new Exception("用户不存在！");}
			if(!(rst.getString("userpwd").equals(user.getUserpwd()))) 
			{
				throw new Exception("密码错误！");
			}
		}catch(Exception e){
			throw e;
		}
		///////////////////////////////////////////////////////////
		vsql="update tb_user set userpwd=? where userid=? ";
		pstmt=con.prepareStatement(vsql);
		pstmt.setString(1,newpwd);
		pstmt.setString(2,userid);
		try{
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}
		//DatabaseConn.close(con, pstmt, rst);
		dbconnection.close(rst, pstmt, con);
	}
	
	/**
	 * @param userid
	 * @throws Exception
	 * 初始化用户密码为123456(e10adc3949ba59abbe56e057f20f883e)
	 */
	public void initializepwd(String userid)throws Exception{
		//Connection con=DatabaseConn.getConnection();
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		String vsql="update tb_user set userpwd='e10adc3949ba59abbe56e057f20f883e' where userid='"+userid+"'";
		pstmt=con.prepareStatement(vsql);
		try{
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}
		//DatabaseConn.close(con, pstmt, null);
		dbconnection.close(null, pstmt, con);
	}
	public void deleteinfo(String struserid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		String vsql="delete from tb_user where userid='"+struserid+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		pstmt.execute();
		dbconnection.close(null, pstmt, con);
		//DatabaseConn.close(con, pstmt, null);
	}
	public void isexisted(UserBean user)throws Exception 
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		if(user==null) {throw new Exception("用户未登录，无权访问该页面！");}
		//有效性验证
		String vsql ="select * from tb_user where userid='"+user.getUserid()+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=null;
		try{
			rst=pstmt.executeQuery();
		
				if(rst.next()) {
					//System.out.print(rst.getString("usertype"));
					//System.out.print(rst.getString("userid"));
					//System.out.print(rst.getString("username"));
					//System.out.print(rst.getString("userpwd"));
			
			}//ceshi
				else if(!rst.next()){throw new Exception("用户不存在！");}
				if(!(rst.getString("usertype").equals(user.getUsertype()))) 
			{
				throw new Exception("用户类型错误！");
			}
				 if(!(rst.getString("userpwd").equals(user.getUserpwd()))) 
			{
				throw new Exception("密码错误！");
			}
		}catch(Exception e){
			//e.printStackTrace();
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
			//DatabaseConn.close(con, pstmt, rst);
		}
	}
}
