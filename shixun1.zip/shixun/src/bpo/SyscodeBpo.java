package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.dbconnection;

import bean.ClassBean;
import bean.SyscodeBean;
public class SyscodeBpo {
	/**增加/修改代码信息*/
	public void addOrmod(SyscodeBean syscode)throws Exception 
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			String vsql="insert into tb_syscode (codeid,codeno,codename,codevalue,codecontent) values(?,?,?,?,?)";
			pstmt=con.prepareStatement(vsql);
			pstmt.setString(1,syscode.getCodeid());
			pstmt.setString(2,syscode.getCodeno());
			pstmt.setString(3,syscode.getCodename());
			pstmt.setString(4,syscode.getCodevalue());
			pstmt.setString(5, syscode.getCodecontent());
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
	}
	//获取全部代码信息  根据代码名称
	public List<SyscodeBean> getAllinfo(String codename)throws Exception
	{    		
		Connection con=dbconnection.getConnection();
		if(codename==null) codename="";
		String vsql="select * from tb_syscode where codename like '"+codename+"%' order by codeid";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		List<SyscodeBean> ret=new ArrayList<SyscodeBean>();
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			while(rst.next())
			{
				SyscodeBean temp=new SyscodeBean();
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));;
				temp.setCodecontent(rst.getString("codecontent"));
				ret.add(temp);
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return ret;
	}
	//获取全部  无条件查询  用于返回列表   该方法后序还能用于其他
	public List<SyscodeBean> getAllinfo()throws Exception
	{    		
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_syscode group by codename";//group by 分组去重
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		List<SyscodeBean> ret=new ArrayList<SyscodeBean>();
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			while(rst.next())
			{
				SyscodeBean temp=new SyscodeBean();
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));;
				temp.setCodecontent(rst.getString("codecontent"));
				ret.add(temp);
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return ret;
	}
	//通过代码编号查询获取下拉列表数据  用于教师表教研室下拉菜单
	public List<SyscodeBean> getcodeByno(String codeno)throws Exception
	{   
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_syscode where codeno ='"+codeno+"' order by codevalue";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		List<SyscodeBean> ret=new ArrayList<SyscodeBean>();
		while(rst.next())
		{
			SyscodeBean temp=new SyscodeBean();
			temp.setCodeid(rst.getString("codeid"));
			temp.setCodeno(rst.getString("codeno"));
			temp.setCodename(rst.getString("codename"));
			temp.setCodevalue(rst.getString("codevalue"));
			temp.setCodecontent(rst.getString("codecontent"));
			ret.add(temp);
		}
		dbconnection.close(rst, pstmt, con);
		return ret;
	}
	//根据代码id查询唯一代码实体   用于关联教师等表 修改增加信息
	public SyscodeBean getcodeByid(String codeid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_syscode where codeid ="+codeid;
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		SyscodeBean temp=new SyscodeBean();
		while(rst.next())
		{
			temp.setCodeid(rst.getString("codeid"));
			temp.setCodeno(rst.getString("codeno"));
			temp.setCodename(rst.getString("codename"));
			temp.setCodevalue(rst.getString("codevalue"));
			temp.setCodecontent(rst.getString("codecontent"));
		}
		dbconnection.close(rst, pstmt, con);
		return temp;
	}
	//根据带密码编号 和 代码值   
	public SyscodeBean getcode(String codeno,String codevalue)throws Exception
	{
		Connection con=dbconnection.getConnection();
		SyscodeBean temp=new SyscodeBean();
		String vsql="select * from tb_syscode where codeno ='"+codeno+"' and codevalue='"+codevalue+"'";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next()) {
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));
				temp.setCodecontent(rst.getString("codecontent"));
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return temp;
	}
	//获取教研室名称
	public SyscodeBean gettdeptname(String codevalue)throws Exception
	{   
		String codeno="jxdw";
		Connection con=dbconnection.getConnection();
		SyscodeBean temp=new SyscodeBean();
		String vsql="select * from tb_syscode where codeno ='"+codeno+"' and codevalue='"+codevalue+"'";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next()) {
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));
				temp.setCodecontent(rst.getString("codecontent"));
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return temp;
	}
	//获取职称名称
	public SyscodeBean gettpostname(String codevalue)throws Exception
	{   
		String codeno="zhch";
		Connection con=dbconnection.getConnection();
		SyscodeBean temp=new SyscodeBean();
		String vsql="select * from tb_syscode where codeno ='"+codeno+"' and codevalue='"+codevalue+"'";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next()) {
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));
				temp.setCodecontent(rst.getString("codecontent"));
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return temp;
	}
	//获取学位名称
	public SyscodeBean gettdegreename(String codevalue)throws Exception
	{   
		String codeno="xw";
		Connection con=dbconnection.getConnection();
		SyscodeBean temp=new SyscodeBean();
		String vsql="select * from tb_syscode where codeno ='"+codeno+"' and codevalue='"+codevalue+"'";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next()) {
				temp.setCodeid(rst.getString("codeid"));
				temp.setCodeno(rst.getString("codeno"));
				temp.setCodename(rst.getString("codename"));
				temp.setCodevalue(rst.getString("codevalue"));
				temp.setCodecontent(rst.getString("codecontent"));
			}
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return temp;
	}
	public void modifyinfo(SyscodeBean code)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		    try{
			String vsql="update tb_syscode set codeno=?,codename=?,codevalue=?, codecontent=?where codeid=?";
		    pstmt=con.prepareStatement(vsql);		
			pstmt.setString(1,code.getCodeno());
			pstmt.setString(2,code.getCodename());
			pstmt.setString(3,code.getCodevalue());
			pstmt.setString(4,code.getCodecontent());
			pstmt.setString(5,code.getCodeid());
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(null, pstmt, con);
		}
	}
	//删除信息
	public void deleteinfo(String codeid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		try{
			String vsql="delete from tb_syscode where codeid='"+codeid+"'";
			pstmt=con.prepareStatement(vsql);
			pstmt.executeUpdate();		
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(null, pstmt, con);
		}
	}
}
