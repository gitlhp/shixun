/**
 * 
 */
package bpo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dbconnection;

import bean.SysarguBean;

/**
 * @author wyx
 * wxh2011-12-31修改
 *
 */
public class SysarguBpo {
	/**按名字获得系统参数条目*/
	public List<SysarguBean> getSysargu(String arguname) throws SQLException
	{  
		System.out.println(arguname);
	 Connection con=dbconnection.getConnection();
	 PreparedStatement pstm=null;
	 ResultSet rst=null;
	 String  sql="select * from tb_sysargu where arguname=?";
	 pstm=con.prepareStatement(sql);
	 pstm.setString(1, arguname);
	 rst=pstm.executeQuery();
	 List<SysarguBean> ret=new ArrayList<SysarguBean>(); 	 
	 while(rst.next()) {
		 SysarguBean argu=new SysarguBean();
		 //System.out.println("fffggg");
		  argu.setArguid(rst.getInt("arguid"));
		  argu.setArguname(rst.getString("arguname"));
		  argu.setArgutype(rst.getString("argutype"));
		  argu.setArguvalue(rst.getString("arguvalue"));
		  argu.setRemark(rst.getString("remark"));
		  ret.add(argu);
	}   
	 dbconnection.close(rst, pstm, con);
		return ret;
	}
	/**得到系统参数列表*/
	public List<SysarguBean> getAllsysargu() throws SQLException
	{
		 Connection con=dbconnection.getConnection();
		 PreparedStatement pstm=null;
		 ResultSet rst=null;
		 String  sql="select * from tb_sysargu order by arguid";
		 pstm=con.prepareStatement(sql);
		 rst=pstm.executeQuery();
		 List<SysarguBean> syslist=new ArrayList<SysarguBean>(); 		
		 while(rst.next()) {
			 SysarguBean argu=new SysarguBean();
			  argu.setArguid(rst.getInt("arguid"));
			  argu.setArguname(rst.getString("arguname"));
			  argu.setArgutype(rst.getString("argutype"));
			  argu.setArguvalue(rst.getString("arguvalue"));
			  argu.setRemark(rst.getString("remark"));
			  syslist.add(argu);
		}
		 dbconnection.close(rst, pstm, con);
			return syslist;
	}
	/**按照参数名修改参数值*/
	public void modifyArguByName(String arguname,String arguvalue) throws Exception
	{  
		Connection con=dbconnection.getConnection();
	    PreparedStatement pstm=null;
	    try {
	    	System.out.println(arguname);
	    	String sqlString="update tb_sysargu set arguvalue='"+arguvalue+"' where arguname='"+arguname+"'";
			pstm=con.prepareStatement(sqlString);
			pstm.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			dbconnection.close(null, pstm, con);
		}	
		
	}
}
