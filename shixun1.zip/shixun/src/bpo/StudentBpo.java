package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.dbconnection;

import bean.StudentBean;

public class StudentBpo {
	public StudentBpo()throws Exception
	{
	}
	//
	public void addinfo(StudentBean student)throws Exception 
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		//有效性验证
		String vsql ="select * from tb_student where stuid='"+student.getStuid()+"'";
		try{
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(rst.next())
			{
				if(student.getStuid().equals(rst.getString("stuid")))
				{ 
					throw new Exception(student.getStuid()+"学号已存在！");
				}
			}
		}catch(Exception e){
			throw e;
		}finally{
			//DatabaseConn.close(null, pstmt, rst);
			dbconnection.close(rst, pstmt, null);
		}
		//判断班级名是否有效
		try{
			vsql="select * from tb_class where classname='"+student.getClassname()+"'";
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
			if(!rst.next())	throw new Exception(student.getStuid()+"的班级名称不存在！");
		}catch(Exception e){
			throw e;
		}finally{
			//DatabaseConn.close(null, pstmt, rst);
			dbconnection.close(rst, pstmt, null);
		}
		con.setAutoCommit(false);//不自动 Commit (瓜子不是一个一个吃,全部剥开放桌子上,然后一口舔了)
		/*
		 * 循环里连续的进行插入操作，如果你在开始时设置了：conn.setAutoCommit(false);  
最后才进行conn.commit(),这样你即使插入的时候报错，修改的内容也不会提交到数据库，  
而如果你没有手动的进行setAutoCommit(false);  
出错时就会造成，前几条插入，后几条没有  
会形成脏数据~~  
		 */
		PreparedStatement pstmt1=null;
		try{
			vsql="insert into tb_student(stuid,sname,classname,email,telphone) values(?,?,?,?,?)";
			String vsql1="insert into tb_user(usertype,userid,username,userpwd) values(?,?,?,?)";
			pstmt=con.prepareStatement(vsql);
			pstmt.setString(1,student.getStuid());
			pstmt.setString(2,student.getSname());
			pstmt.setString(3,student.getClassname());
			pstmt.setString(4,student.getEmail());
			pstmt.setString(5,student.getTelphone());
			pstmt.executeUpdate();
			
			pstmt1=con.prepareStatement(vsql1);
			pstmt1.setString(1,"学生");
			pstmt1.setString(2, student.getStuid());
			pstmt1.setString(3, student.getSname());
			pstmt1.setString(4,"e10adc3949ba59abbe56e057f20f883e");//新增用户默认密码为123456
			pstmt1.executeUpdate();
			
			con.commit();//提交事务
		}catch(Exception e){
			con.rollback();
			throw e;
		}finally{
			//DatabaseConn.close(null, pstmt, rst);
			//DatabaseConn.close(null, pstmt1, null);
			dbconnection.close(rst, pstmt, null);
			dbconnection.close(rst, pstmt1, null);
			con.setAutoCommit(true);
		}
	}
	//批量录入学生基本信息（导入文件调用）
	public void addinfoBatch(List<StudentBean> students)throws Exception 
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		PreparedStatement pstmt1=null;
		con.setAutoCommit(false);
		try{
			Iterator<StudentBean> it = students.iterator();//获取迭代器  游标
			String vsql="insert into tb_student(stuid,sname,classname) values(?,?,?)";
			String vsql1="insert into tb_user(usertype,userid,username,userpwd) values(?,?,?,?)";
			pstmt=con.prepareStatement(vsql);
			pstmt1=con.prepareStatement(vsql1);//插入
			//3.预编译SQL语句,只编译一回哦,效率高啊.(发明一个剥瓜子的方法,以后不要总想怎么剥瓜子好.就这样剥.)
			while (it.hasNext()) {//下一条还有数据的话
				/*2)使用next()获得序列中的下一个元素。
			       3)使用hasNext()检查序列中是否还有元素。
			       4)使用remove()将上一次返回的元素从迭代器中移除。
			       5)ResultSet结果集使用next()判断是否还存在元素和指向记录  迭代器  分别使用3,2两种方法
				 **/
				//System.out.print("333334444");
				StudentBean temp=it.next();
				//学生有效性验证
				PreparedStatement pstmt0=null;
				ResultSet rst=null;
				/*有效性验证开始*/
				String vsql0 ="select * from tb_student where stuid='"+temp.getStuid()+"'";
				try{
					pstmt0=con.prepareStatement(vsql0);
					rst=pstmt0.executeQuery();
					if(rst.next())//验证一条数据
					{    System.out.print(rst.getString("stuid"));
						if(temp.getStuid().equals(rst.getString("stuid")))
						{ 
							throw new Exception(temp.getStuid()+"学号已存在！");
						}
					}
				}catch(Exception e){
					throw e;
				}finally{
					//DatabaseConn.close(null, pstmt0, rst);
					dbconnection.close(rst, pstmt0, null);
				}
				//判断班级名是否有效  输入班级不在范围内 报错
				try{
					vsql0="select * from tb_class where classname='"+temp.getClassname()+"'";
					pstmt0=con.prepareStatement(vsql0);
					rst=pstmt0.executeQuery();
					if(!rst.next())	throw new Exception(temp.getStuid()+"的班级名称'"+temp.getClassname()+"'不存在！");
				}catch(Exception e){
					throw e;
				}finally{
					//DatabaseConn.close(null, pstmt0, rst);
					dbconnection.close(rst, pstmt0, null);
				}
				/*验证结束*/
				//插入
				pstmt.setString(1,temp.getStuid());
				pstmt.setString(2,temp.getSname());
				pstmt.setString(3,temp.getClassname());
				pstmt.addBatch();//再添加一次预定义参数  为了批量执行
				
				pstmt1.setString(1,"学生");
				pstmt1.setString(2, temp.getStuid());
				pstmt1.setString(3, temp.getSname());
				pstmt1.setString(4,"e10adc3949ba59abbe56e057f20f883e");//新增用户默认密码为123456
				pstmt1.addBatch();
			}
			
			pstmt.executeBatch();//循环完  批量执行  爽歪歪！
			pstmt1.executeBatch();
			con.commit();
		}catch(Exception e){
			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
			//DatabaseConn.close(null, pstmt, null);
			//DatabaseConn.close(con, pstmt1, null);
			dbconnection.close(null, pstmt, null);
			dbconnection.close(null, pstmt1, con);
		}
	}
	//获取所有学生的信息
	public List<StudentBean> getAllinfo(String specid,String classname,String sname)throws Exception
	{  //System.out.print("ssss");
		Connection con=dbconnection.getConnection();
		if(classname==null) classname="";
		if(sname==null) sname="";
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		List<StudentBean> ret=new ArrayList<StudentBean>();
		try{
			if(specid==null||specid.equals("")){ 
				throw new Exception("专业不能为空！");
				}
			String vsql="select * from tb_student where classname like '"+classname+"%' and sname like '"+sname+"%' "+
			            " and classname in (select classname from tb_class where specid='"+specid+"') "+ 
			            "order by classname,stuid";//在已有的班级表中找
			pstmt=con.prepareStatement(vsql);
			rst=pstmt.executeQuery();
		
			while(rst.next())//结果集的吓一条记录  
			{     
				//System.out.print("rrrr");
				StudentBean temp=new StudentBean();
				temp.setStuid(rst.getString("stuid"));//temp.setStuid(rst.getInt(1));第一列取值
				temp.setSname(rst.getString("sname"));
				temp.setSsex(rst.getString("ssex"));
				String classname0=rst.getString("classname");
				temp.setClassname(classname0);
				ClassBpo classbpo=new ClassBpo();
				temp.setClassbean(classbpo.getByclassname(classname0));
				temp.setEmail(rst.getString("email"));
				temp.setTelphone(rst.getString("telphone"));
				temp.setRemark(rst.getString("remark"));
				ret.add(temp);
			}

		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		return ret;//返回一个学生集合
	}
	//查询一个学生
	public StudentBean getBystuid(String stuid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_student where stuid = '"+stuid+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		StudentBean temp=new StudentBean();
		while(rst.next())
		{
			temp.setStuid(rst.getString("stuid"));
			temp.setSname(rst.getString("sname"));
			temp.setSsex(rst.getString("ssex"));
			String classname=rst.getString("classname");
			temp.setClassname(classname);
			ClassBpo classbpo=new ClassBpo();
			temp.setClassbean(classbpo.getByclassname(classname));
			temp.setEmail(rst.getString("email"));
			temp.setTelphone(rst.getString("telphone"));
			temp.setRemark(rst.getString("remark"));
		}
		//DatabaseConn.close(con, pstmt, rst);
		dbconnection.close(rst, pstmt, con);
		return temp;
	}
	//修改一个学生
	public void modifyinfo(StudentBean student)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//有效性验证
		PreparedStatement pstmt=null;
		try{
			String vsql="update tb_student set sname=?,ssex=?,classname=?,email=?,telphone=?,remark=? where stuid=? ";
		    pstmt=con.prepareStatement(vsql);
		
			pstmt.setString(1,student.getSname());
			pstmt.setString(2,student.getSsex());
			pstmt.setString(3,student.getClassname());
			pstmt.setString(4,student.getEmail());
			pstmt.setString(5,student.getTelphone());
			pstmt.setString(6,student.getRemark());
			pstmt.setString(7,student.getStuid());
			//pstmt.executeUpdate();
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			//DatabaseConn.close(con, pstmt, null);
			dbconnection.close(null, pstmt, con);
		}
	}
	/**
	 * @param student 学生个人能修改除编号、姓名、班级之外的其他信息
	 * @throws Exception
	 */
	//权限较小的修改
	public void modifypersonalinfo(StudentBean student)throws Exception
	{
		Connection con=dbconnection.getConnection();
		//Connection con=DatabaseConn.getConnection();
		PreparedStatement pstmt=null;
		String vsql;
		///////////////////////////////////////////////////////////
		vsql="update tb_student set ssex=?,email=?,telphone=? where stuid=? ";
	    pstmt=con.prepareStatement(vsql);
		pstmt.setString(1,student.getSsex());
		pstmt.setString(2,student.getEmail());
		pstmt.setString(3,student.getTelphone());
		pstmt.setString(4,student.getStuid());
		
		pstmt.execute();
		//DatabaseConn.close(con, pstmt, null);
		dbconnection.close(null, pstmt, con);
	}
	/**按学号删除学生信息*/
	public void deleteinfo(String stuid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		//删除学生信息和用户信息
		PreparedStatement pstmt1=null;
		con.setAutoCommit(false);//批量
		try{
			String vsql="delete from tb_student where stuid='"+stuid+"'";
			String vsql1="delete from tb_user where userid='"+stuid+"'";
			pstmt=con.prepareStatement(vsql);
			pstmt1=con.prepareStatement(vsql1);
			pstmt.executeUpdate();
			pstmt1.executeUpdate();			
			con.commit();
		}catch(Exception e){
			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
			dbconnection.close(null, pstmt1, null);
			dbconnection.close(null, pstmt, con);
		}
	}
	
}
