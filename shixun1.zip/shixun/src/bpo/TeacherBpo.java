package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.dbconnection;

import bean.StudentBean;
import bean.TeacherBean;
import bean.SyscodeBean;
import bpo.SyscodeBpo;

/**
 * @author wxh
 *
 */
public class TeacherBpo {
	public TeacherBpo()throws Exception
	{
	}
	/**
	 * @param teacher
	 * @throws Exception
	 * 增加教师基本信息，同时增加教师用户
	 */
	public void addinfo(TeacherBean teacher)throws Exception 
	{
		Connection con=dbconnection.getConnection();
	PreparedStatement pstmt=null;
	ResultSet rst=null;
	//有效性验证
	String vsql ="select * from tb_teacher where tid='"+teacher.getTid()+"'";
	try{
		pstmt=con.prepareStatement(vsql);
		rst=pstmt.executeQuery();
		if(rst.next())
		{
			if(teacher.getTid().equals(rst.getString("tid")))
			{ 
				throw new Exception(teacher.getTid()+"该教师已存在！");
			}
		}
	}catch(Exception e){
		throw e;
	}finally{
		dbconnection.close(rst, pstmt, null);
	}
	con.setAutoCommit(false);
	PreparedStatement pstmt1=null;
	try{ //增加信息  根据code表
		String codeid=teacher.getTdeptname();
		String codeid1=teacher.getTpostname();
		String codeid2=teacher.getTdegreename();
		SyscodeBpo syscodeBpo=new SyscodeBpo();
		String  tdept=syscodeBpo.getcodeByid(codeid).getCodevalue();
		String  tpost=syscodeBpo.getcodeByid(codeid1).getCodevalue();
		String  tdegree=syscodeBpo.getcodeByid(codeid2).getCodevalue();
		vsql="insert into tb_teacher (tid,tname,tdept,tpost,tdegree) values(?,?,?,?,?)";
		String vsql1="insert into tb_user(usertype,userid,username,userpwd) values(?,?,?,?)";
		pstmt=con.prepareStatement(vsql);
		pstmt.setString(1,teacher.getTid());
		pstmt.setString(2,teacher.getTname());
		pstmt.setString(3,tdept);;
		pstmt.setString(4,tpost);//2018/1/10  21:21改的bug
		pstmt.setString(5,tdegree);
		pstmt.executeUpdate();
		
		pstmt1=con.prepareStatement(vsql1);
		pstmt1.setString(1,"教师");
		pstmt1.setString(2, teacher.getTid());
		pstmt1.setString(3, teacher.getTname());
		pstmt1.setString(4,"e10adc3949ba59abbe56e057f20f883e");//新增用户默认密码为123456
		pstmt1.executeUpdate();		
		con.commit();//提交事务
	}catch(Exception e){
		con.rollback();
		throw e;
	}finally{
		dbconnection.close(rst, pstmt, null);
		dbconnection.close(rst, pstmt1, null);
		con.setAutoCommit(true);
	}
}
	/**
	 * @param teachers
	 * @throws Exception
	 * 批量录入教师基本信息（导入文件调用）
	 */
	public void addinfoBatch(List<TeacherBean> teachers)throws Exception 
	{
		Connection con=dbconnection.getConnection();
	PreparedStatement pstmt=null;
	PreparedStatement pstmt1=null;
	con.setAutoCommit(false);
	try{
		Iterator<TeacherBean> it = teachers.iterator();//获取迭代器  游标
		String vsql="insert into tb_teacher(tid,tname,tdept,tpost,tdegree) values(?,?,?,?,?)";
		String vsql1="insert into tb_user(usertype,userid,username,userpwd) values(?,?,?,?)";
		pstmt=con.prepareStatement(vsql);
		pstmt1=con.prepareStatement(vsql1);//插入
		System.out.println("444557df");
		while (it.hasNext()) {//下一条还有数据的话  用于跌打器
			//System.out.println("444557df");
			TeacherBean temp=it.next();
			//教师有效性验证
			PreparedStatement pstmt0=null;
			ResultSet rst=null;
			/*有效性验证开始*/
			String vsql0 ="select * from tb_teacher where tid='"+temp.getTid()+"'";
			try{
				pstmt0=con.prepareStatement(vsql0);
				rst=pstmt0.executeQuery();
				if(rst.next())//验证一条数据
				{   // System.out.print(rst.getString("tid"));
					if(temp.getTid().equals(rst.getString("tid")))
					{ 
						throw new Exception(temp.getTid()+"该教师已存在！");
					}
				}
			}catch(Exception e){
				throw e;
			}finally{
				//DatabaseConn.close(null, pstmt0, rst);
				dbconnection.close(rst, pstmt0, null);
			}
			//教师的索索专业教研室与其他表有什么联系？没想好  先放一放。  //有答案了
			/*此处需要验证字段
			/*验证结束*/
			//插入//职工号、姓名、教研室代码、职称代码、学位代码
			pstmt.setString(1,temp.getTid());
			pstmt.setString(2,temp.getTname());
			pstmt.setString(3,temp.getTdept());
			pstmt.setString(4,temp.getTpost());
			pstmt.setString(5,temp.getTdegree());
			pstmt.addBatch();//再添加一次预定义参数  为了批量执行   就是相当于又写了一句新的带参数的insert语句
			
			pstmt1.setString(1,"教师");
			pstmt1.setString(2, temp.getTid());
			pstmt1.setString(3, temp.getTname());
			pstmt1.setString(4,"e10adc3949ba59abbe56e057f20f883e");//新增用户默认密码为123456
			pstmt1.addBatch();
		}
		pstmt.executeBatch();//循环完  批量执行  爽歪歪！
		pstmt1.executeBatch();
		con.commit();
	}catch(Exception e){
		con.rollback();
		throw e;
	}finally{
		con.setAutoCommit(true);
		dbconnection.close(null, pstmt, null);
		dbconnection.close(null, pstmt1, con);
	}
	}
	
	public List<TeacherBean> getAllinfo()throws Exception
	{
	
		List<TeacherBean> ret=new ArrayList<TeacherBean>();
		//……………………	…………………………………………
		return ret;
	}
	
	/**
	 * @param tdept
	 * @param tname
	 * @return List<TeacherBean>
	 * @throws Exception  需要获取代码表数据    此代码获取代码值得部分  修改代码后用不到  但不用修改  
	 */
	public List<TeacherBean> getAllinfo(String tdept,String tid,String tname)throws Exception
	{   
		  Connection con=dbconnection.getConnection();
			if(tid==null) tid="";
			if(tname==null) tname="";//模糊查询类似
			PreparedStatement pstmt=null;
			ResultSet rst=null;
			List<TeacherBean> ret=new ArrayList<TeacherBean>();
			try{
				if(tdept==null||tdept.equals("")){ 
					throw new Exception("教研室不能为空！");
					}
				String vsql="select * from tb_teacher where tdept like '"+tdept+"%' and tid like '"+tid+"%' "+
				            " and tname like  '"+tname+"%'"+ 
				            "order by tid";//在已有的班级表中找
				pstmt=con.prepareStatement(vsql);
				rst=pstmt.executeQuery();			
				while(rst.next())//结果集的吓一条记录  
				{  //System.out.print("success");
					TeacherBean temp=new TeacherBean();
					temp.setTid(rst.getString("tid"));
					//System.out.print(rst.getString("tid"));
					temp.setTname(rst.getString("tname"));
					temp.setTsex(rst.getString("tsex"));
					temp.setTdept(rst.getString("tdept"));//codevalue  找  codecontent  加个参数 jxdw
					temp.setTpost(rst.getString("tpost"));
					temp.setTdegree(rst.getString("tdegree"));
					String tpost=rst.getString("tpost");
					String tdegree=rst.getString("tdegree");
                    SyscodeBpo syscodeBpo=new SyscodeBpo();
                    String tdeptname=syscodeBpo.gettdeptname(tdept).getCodecontent();
                    String tpostname=syscodeBpo.gettpostname(tpost).getCodecontent();
                    String tdegreename=syscodeBpo.gettdegreename(tdegree).getCodecontent();
				    temp.setTdeptname(tdeptname);
				    temp.setTpostname(tpostname);
				    temp.setTdegreename(tdegreename);
					temp.setStudydirect(rst.getString("studydirect"));
					temp.setEmail(rst.getString("email"));
					temp.setTelphone(rst.getString("telphone"));
					temp.setRemark(rst.getString("remark"));				
					ret.add(temp);
				}

			}catch(Exception e){
				throw e;
			}finally{
				dbconnection.close(rst, pstmt, con);
			}
			return ret;//返回一个教师集合
	}
	//获取一位教师
	public TeacherBean getBytid(String tid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_teacher where tid = '"+tid+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		TeacherBean temp=new TeacherBean();
		while(rst.next())
		{
			temp.setTid(rst.getString("tid"));
			temp.setTname(rst.getString("tname"));
			temp.setTsex(rst.getString("tsex"));
			temp.setTdept(rst.getString("tdept"));
			temp.setTpost(rst.getString("tpost"));
			temp.setTdegree(rst.getString("tdegree"));
			temp.setStudydirect(rst.getString("studydirect"));
			temp.setEmail(rst.getString("email"));
			temp.setTelphone(rst.getString("telphone"));
			temp.setRemark(rst.getString("remark"));							
		}
		dbconnection.close(rst, pstmt, con);
		return temp;
	}
	//修改教师信息  管理员权限
	public void modifyinfo(TeacherBean teacher)throws Exception
	{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;	
		try{
			String codeid=teacher.getTdeptname();
			String codeid1=teacher.getTpostname();
			String codeid2=teacher.getTdegreename();
			SyscodeBpo syscodeBpo=new SyscodeBpo();
			String  tdept=syscodeBpo.getcodeByid(codeid).getCodevalue();
			String  tpost=syscodeBpo.getcodeByid(codeid1).getCodevalue();
			String  tdegree=syscodeBpo.getcodeByid(codeid2).getCodevalue();
			String vsql="update tb_teacher set tname=?,tdept=?,tpost=?,tdegree=? where tid=? ";
		    pstmt=con.prepareStatement(vsql);		
			pstmt.setString(1,teacher.getTname());
			pstmt.setString(2,tdept);
			pstmt.setString(3,tpost);
            pstmt.setString(4, tdegree);
            pstmt.setString(5, teacher.getTid());
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			dbconnection.close(null, pstmt, con);
		}
	}
	//删除教师
	public void deleteinfo(String tid)throws Exception
	{   
		//System.out.print(tid);//可以接受参数
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		String vsql="";
		//删除教师信息和用户信息
		PreparedStatement pstmt1=null;
		con.setAutoCommit(false);//批量
		try{
			vsql="delete from tb_teacher where tid='"+tid+"'";
			String vsql1="delete from tb_user where userid='"+tid+"'";
			pstmt=con.prepareStatement(vsql);
			pstmt1=con.prepareStatement(vsql1);	
			pstmt.executeUpdate();//程序到此停止    艹
			pstmt1.executeUpdate();
			con.commit();
		}catch(Exception e){
			con.rollback();
			throw e;
		}finally{
			con.setAutoCommit(true);
			dbconnection.close(null, pstmt1, null);
			dbconnection.close(null, pstmt, con);
		}
	}
	}
