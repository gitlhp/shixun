package bpo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.dbconnection;

import bean.SpecialityBean;


public class SpecialityBpo {
	public SpecialityBpo()throws Exception
	{	}
	//不需要添加专业信息
	public void addinfo(SpecialityBean speciality)throws Exception 
	{  
		Connection con=dbconnection.getConnection();
		//有效性验证
		String vsql ="select * from tb_speciality where specid='"+speciality.getSpecid()+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next())
		{
			if(speciality.getSpecid().equals(rst.getString("specid")))
			{ 
				throw new Exception(speciality.getSpecid()+"专业编号已存在！");
			}
		}

		vsql="insert into tb_speciality values(?,?,?)";
		pstmt=con.prepareStatement(vsql);
		pstmt.setString(1,speciality.getSpecid());
		pstmt.setString(2,speciality.getSpecname());
		pstmt.setString(3,speciality.getSpecmagtid());
		
		try{
			pstmt.execute();
		}
		catch(Exception e){
			throw e;
		}
		dbconnection.close(rst, pstmt, con);
	}
	//获取全部专业信息
	public List<SpecialityBean> getAllinfo()throws Exception
	{
		Connection con=dbconnection.getConnection();
		String vsql="select * from tb_speciality order by specid";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		List<SpecialityBean> ret=new ArrayList<SpecialityBean>();
		TeacherBpo teacherbpo=new TeacherBpo();
		while(rst.next())
		{    //System.out.print("ffff");
			SpecialityBean temp=new SpecialityBean();
			
			temp.setSpecid(rst.getString("specid"));
			temp.setSpecname(rst.getString("specname"));
			String vspecmagtid=rst.getString("specmagtid");
			//在教师表中获取中野负责人姓名
			temp.setSpecmagtid(vspecmagtid);
			temp.setSpecmagtname(teacherbpo.getBytid(vspecmagtid).getTname());
			ret.add(temp);
		}
		dbconnection.close(rst, pstmt, con);
		return ret;
	}
	
	public List<SpecialityBean> getAllinfo(String specid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		if(specid==null) specid="";
		String vsql="select * from tb_speciality where specid like '"+specid+"%' order by specid";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		List<SpecialityBean> ret=new ArrayList<SpecialityBean>();
		while(rst.next())
		{
			SpecialityBean temp=new SpecialityBean();
			temp.setSpecid(rst.getString("specid"));
			temp.setSpecname(rst.getString("specname"));
			temp.setSpecmagtid(rst.getString("specmagtid"));
			ret.add(temp);
		}
		dbconnection.close(rst, pstmt, con);
		return ret;
	}
	//返回一个教师实体  不需要
	public SpecialityBean getByspecid(String specid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		if(null == specid){
			specid="";
		}	
		String vsql="select * from tb_speciality where specid like '"+specid+"%'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		SpecialityBean temp=new SpecialityBean();
		while(rst.next())
		{
			temp.setSpecid(rst.getString("specid"));
			temp.setSpecname(rst.getString("specname"));
			temp.setSpecmagtid(rst.getString("specmagtid"));
		}
		dbconnection.close(rst, pstmt, con);
		return temp;
	}
	/**
	 * @param tid
	 * @return tid管理的专业信息
	 * @throws Exception
	 */
	public SpecialityBean getspecmagBytid(String tid)throws Exception
	{
		Connection con=dbconnection.getConnection();
		if(null == tid){
			tid="";
		}	
		String vsql="select * from tb_speciality where specmagtid ='"+tid+"'";
		PreparedStatement pstmt=con.prepareStatement(vsql);
		ResultSet rst=pstmt.executeQuery();
		SpecialityBean temp=new SpecialityBean();
		while(rst.next())
		{
			temp.setSpecid(rst.getString("specid"));
			temp.setSpecname(rst.getString("specname"));
			temp.setSpecmagtid(rst.getString("specmagtid"));
		}
		dbconnection.close(rst, pstmt, con);
		return temp;
	}
	/**修改专业负责人
	 * @param specid
	 * @param specmagtid 修改后的专业负责人id
	 * @throws Exception  
	 */
	//public void modifySpecMag(String specid,String specmagtid)throws Exception{
		public SpecialityBean modifySpecMag(SpecialityBean specialityBean)throws Exception{
		Connection con=dbconnection.getConnection();
		PreparedStatement pstmt=null;
		ResultSet rst=null;
		//有效性验证  应该就这一条检验吧？待续。。
		try {
			String sql="select * from tb_teacher where tid =?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, specialityBean.getSpecmagtid());
			rst=pstmt.executeQuery();
			if (!rst.next()) {
				throw new Exception("该教师不存在！");
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		}finally{
			dbconnection.close(null, pstmt, null);
		}
		try{
			String vsql="update tb_speciality set specmagtid=? where specid=? ";
		    pstmt=con.prepareStatement(vsql);		
			pstmt.setString(1,specialityBean.getSpecmagtid());
			pstmt.setString(2,specialityBean.getSpecid());	
			//pstmt.executeUpdate();
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
	
			dbconnection.close(null, pstmt, null);
		}
		//获取新的数据
		try {  
			String vsql1="select * from tb_speciality where specid=? ";
			pstmt=con.prepareStatement(vsql1);
			pstmt.setString(1, specialityBean.getSpecid());
			rst=pstmt.executeQuery();
			SpecialityBean temp=new SpecialityBean();
			TeacherBpo teacherbpo=new TeacherBpo();
			if(rst.next())
			{			
				temp.setSpecid(rst.getString("specid"));
				temp.setSpecname(rst.getString("specname"));
				String vspecmagtid=rst.getString("specmagtid");
				//在教师表中获取新负责人姓名
				temp.setSpecmagtid(vspecmagtid);
				temp.setSpecmagtname(teacherbpo.getBytid(vspecmagtid).getTname());
			}
			return temp;			
		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		}finally{
			dbconnection.close(rst, pstmt, con);
		}
		
	}
}
